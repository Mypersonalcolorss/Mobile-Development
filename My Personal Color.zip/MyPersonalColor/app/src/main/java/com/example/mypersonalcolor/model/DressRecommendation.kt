package com.example.mypersonalcolor.model

data class DressRecommendation(val imageUrl: String)
