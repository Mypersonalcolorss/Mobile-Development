package com.example.mypersonalcolor.model

data class ColorPalette(
    val colorName: String,
    val colorHex: String
)
