package com.example.mypersonalcolor

import android.content.Intent
import android.os.Bundle
import android.widget.GridLayout
import android.widget.ImageButton
import android.widget.ImageView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class DashboardActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener { menuItem ->
            // Handle navigation view item clicks here.
            when (menuItem.itemId) {
                R.id.nav_personal_color_analysis -> {
                    // Handle the personal color analysis action
                }
                // Handle other menu item clicks
            }
            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
        setupGridLayout()

        // Set up the hamburger menu (DrawerLayout and NavigationView)
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        // Assuming you have a hamburger button with id btnHamburgerMenu
        val hamburgerMenu: ImageButton = findViewById(R.id.btnHamburgerMenu)
        hamburgerMenu.setOnClickListener {
            // Open the drawer
            drawerLayout.openDrawer(GravityCompat.START)
        }

        // Set up the user profile button
        val userProfileButton: ImageView = findViewById(R.id.btnUserProfile)
        userProfileButton.setOnClickListener {
            // Navigate to the user profile activity
            val intent = Intent(this, UserProfileActivity::class.java)
            startActivity(intent)
        }

    }
    private fun setupGridLayout() {
        val gridLayout: GridLayout = findViewById(R.id.gridLayoutDashboard)
        val drawables = arrayOf(
            R.drawable.ic_user, R.drawable.ic_dress,
            R.drawable.ic_palette, R.drawable.ic_avatar,
            R.drawable.ic_skincare, R.drawable.ic_cs
        )

        drawables.forEachIndexed { index, drawableId ->
            val imageView = ImageView(this).apply {
                layoutParams = GridLayout.LayoutParams(
                    GridLayout.spec(GridLayout.UNDEFINED, 1f),
                    GridLayout.spec(GridLayout.UNDEFINED, 1f)
                ).apply {
                    width = 0 // Use column weight
                    height = resources.getDimensionPixelSize(R.dimen.grid_item_height)
                    setMargins(8, 8, 8, 8)
                }
                setImageResource(drawableId)
                scaleType = ImageView.ScaleType.CENTER_CROP
                setPadding(16, 16, 16, 16)
                setBackgroundResource(R.drawable.grid_item_background)

                setOnClickListener {
                    if (index == 0) { // Assuming R.drawable.ic_user is the first drawable in the array
                        val intent = Intent(this@DashboardActivity, FaceAnalysisActivity::class.java)
                        startActivity(intent)
                    }
                }
            }
            gridLayout.addView(imageView)
        }
    }

}
