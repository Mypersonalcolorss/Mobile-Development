package com.example.mypersonalcolor

import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*
import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider

class FaceAnalysisActivity : AppCompatActivity() {

    private lateinit var ivUserFace: ImageView
    private val cameraRequestCode = 100 // Define a request code for camera

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_face_analysis)

        ivUserFace = findViewById(R.id.ivUserFace)
        val btnAnalyticFaceColor: Button = findViewById(R.id.btnAnalyticFaceColor)
        val btnAutomatic: Button = findViewById(R.id.btnAutomatic)
        val ivLock: ImageView = findViewById(R.id.ivLock)

        btnAnalyticFaceColor.setOnClickListener {
            openCameraForSelfie()
        }

        btnAutomatic.setOnClickListener {
            // Start automatic feature
            startAutomaticFeature()
        }

        ivLock.setOnClickListener {
            // Navigate to upgrade premium feature
            navigateToUpgradePremium()
        }
    }

    private fun openCameraForSelfie() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraRequestCode)
        } else {
            dispatchTakePictureIntent()
        }
    }

    private fun dispatchTakePictureIntent() {
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        try {
            val photoFile = createImageFile()
            photoURI = FileProvider.getUriForFile(
                this,
                this.packageName + ".fileprovider",
                photoFile
            )
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
            startActivityForResult(takePictureIntent, cameraRequestCode)
        } catch (ex: IOException) {
            Toast.makeText(this, "An error occurred while creating the photo file", Toast.LENGTH_SHORT).show()
        } catch (ex: ActivityNotFoundException) {
            Toast.makeText(this, "No camera app available", Toast.LENGTH_SHORT).show()
        }
    }




    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        when (requestCode) {
            cameraRequestCode -> {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    dispatchTakePictureIntent()
                } else {
                    Toast.makeText(this, "Camera permission is required to use this feature", Toast.LENGTH_SHORT).show()
                }
            }
            else -> super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == cameraRequestCode && resultCode == RESULT_OK) {
            photoURI?.also {
                ivUserFace.setImageURI(it)
            }
        }
    }



    private fun startAutomaticFeature() {
        Toast.makeText(this, "Automatic feature coming soon!", Toast.LENGTH_SHORT).show()
    }

    private fun navigateToUpgradePremium() {
        Toast.makeText(this, "Upgrade to premium coming soon!", Toast.LENGTH_SHORT).show()
    }

    private var photoURI: Uri? = null

    @Throws(IOException::class)
    private fun createImageFile(): File {
        // Create an image file name
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir: File? = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile(
            "JPEG_${timeStamp}_", /* prefix */
            ".jpg", /* suffix */
            storageDir /* directory */
        ).also {
            // Save a file: path for use with ACTION_VIEW intents
            photoURI = FileProvider.getUriForFile(
                this,
                this.packageName + ".fileprovider",
                it
            )
        }
    }

}
